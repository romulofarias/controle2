function dL = modelo_linear(t,L,Vp)
    dL = zeros(2,1);
    dL(1) = -0.066*L(1) + 0.2127*Vp;
    dL(2) = -0.066*L(2) + 0.066*L(1);
endfunction
