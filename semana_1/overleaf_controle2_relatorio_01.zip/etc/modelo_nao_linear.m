function dL = modelo_nao_linear(t,L,Vp)
    dL = zeros(2,1);
    dL(1) = -0.51*sqrt(L(1)) + 0.2127*Vp;
    dL(2) = -0.51*sqrt(L(2)) + 0.51*sqrt(L(1));
endfunction
% f = @(t,L,Vp) [-0.51*sqrt(L(1)) + 0.2127*Vp; -0.51*sqrt(L(2)) + 0.51*sqrt(L(1))]
%[t,L] = ode45(f,linspace(0,2*60,1000),[0,0],9.3)
