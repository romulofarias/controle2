% ELE0512 - SISTEMAS DE CONTROLE - UFRN 2024.1
% SIMULADOR DA DINAMICA DE CONTROLE DE NIVEL DE TANQUES CASCATEADOS
close all, clear all, clc;
% Condicoes iniciais do sistema
L1i = 0; L2i = 0; vp0 = 9.3;

% h1: altura do tanque 1
% h2: altura do tanque 2
[t,h] = ode45(@(t,L,Vp) modelo_nao_linear(t,L,Vp),linspace(0,2*60,1000),[L1i,L2i],vp0);

plot(t,h(:,1),";Tanque 1;");% dinamica do tanque 1
set(gca,"fontsize",14);%configura tamanho da fonte na figura
title("Resposta temporal do sistema")
xlabel("Tempo (s)");
ylabel("Altura (cm)");
hold on;
plot(t,h(:,2),";Tanque 2;");% dinamica do tanque 2

[t,g] = ode45(@(t,L,Vp) modelo_linear(t,L,Vp),linspace(0,2*60,1000),[L1i,L2i],4.66);

plot(t,g(:,1),"--;Tanque 1 linear;");% dinamica do tanque 1 linearizado
plot(t,g(:,2),"--;Tanque 2 linear;");% dinamica do tanque 2 linearizado

